package com.example.helloword;


import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;


public class SplashScreenActivity extends AppCompatActivity {
    private final int TIME_DELAY = 4000;
    private static final String FIRST_USED = "primeiraVez";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        boolean primeiraVez = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean(FIRST_USED, true);
        if (primeiraVez) {
            PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
                    .edit()
                    .putBoolean(FIRST_USED, false)
                    .commit();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    ShowMain();
                }
            }, TIME_DELAY);

            Toast.makeText(this, "Bem-Vindo ao App Hello World!", Toast.LENGTH_SHORT).show();
        } else {
            ShowMain();
        }
    }

    private void ShowMain()
    {
        Intent mainIntent = new Intent( SplashScreenActivity.this, MainActivity.class);
        startActivity(mainIntent);
        finish();
    }
}
